package modelo.interfaces;

public interface InfoCliente {
    void mostrarInformacionCliente();
}